# CHANGELOG DARKSODA

v 0.0.1

* First version

v 0.0.3

* Fix1

v 0.0.4

* Small improvement
* Add License in file CSS

v 0.0.5

* Add .CodeMirror-foldmarker

v 0.0.6

* https://github.com/Brackets-Themes/DarkSoda/pull/2

v 0.1.0

* Add /* Show Whitespace (https://github.com/DennisKehrig/brackets-show-whitespace)*/
* Add /* Code Folding (https://github.com/thehogfather/brackets-code-folding)*/
* Add /* New Class for Brackets 0.43 (searching)*/
* Change .CodeMirror .CodeMirror-overwrite .CodeMirror-cursor
* Remove .cm-s-dark-soda span.CodeMirror-searching
* Remove #editor-holder #not-editor
* Remove #not-editor:before
* Remove .CodeMirror-selected 
* Remove #main-toolbar
* Fix error in .cm-s-dark-soda span.cm-matchhighlight {background-color
* Fix and change .CodeMirror-activeline-background, .CodeMirror-activeline .CodeMirror-gutter-elt
* Change padding in .CodeMirror .CodeMirror-linenumber
* Add .CodeMirror-selected
* Many errors fixed!!
* Add .cm-error
* change .cm-tag remove !important
* Add color in .CodeMirror .CodeMirror-linenumber

v 0.1.1

* Remove !important in  .CodeMirror-cursor and .CodeMirror .CodeMirror-overwrite .CodeMirror-cursor

v 0.1.2

* Remove main.js in Brackets 1.0.0